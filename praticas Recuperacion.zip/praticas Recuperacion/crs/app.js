'use strick'

