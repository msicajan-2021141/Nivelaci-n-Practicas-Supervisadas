'use strick'

const { create } = require("domain")
